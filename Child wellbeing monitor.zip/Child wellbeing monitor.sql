/*****SCRIPTS FOR CHILD WELLBEING MONITOR *****/

--Transaction Isolation Level
USE [ADB Task1];  
GO  
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

/***All Views***/


/******Child Health and Wellbeing View******/
CREATE VIEW Child_Health_Condtion AS
SELECT childid,  Cohort = CASE yc WHEN 0 THEN 'Older' WHEN 1 THEN 'Younger' ELSE 'Not Specified' END,
Serious_Illness = Case  chillness WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified'END,
Disability = Case  chdisability WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified'END,
Deadly_illness = Case  chmightdie WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified' END,
Childs_general_health = case chhealth WHEN 1 THEN 'very poor' WHEN 2 THEN 'poor' WHEN 3 THEN 'average' 
WHEN 4 THEN 'good' WHEN 5 THEN 'very good' ELSE 'Not Specified' END, 
Longterm_Health_problem = Case  chhprob WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified' END, 'Vietnam' as Country
FROM vietnam_constructed$
WHERE round = 5
UNION
SELECT childid,  Cohort = CASE yc WHEN 0 THEN 'Older' WHEN 1 THEN 'Younger' ELSE 'Not Specified' END,
Serious_Illness = Case  chillness WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified'END,
Disability = Case  chdisability WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified'END,
Deadly_illness = Case  chmightdie WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified' END,
Childs_general_health = case chhealth WHEN 1 THEN 'very poor' WHEN 2 THEN 'poor' WHEN 3 THEN 'average' 
WHEN 4 THEN 'good' WHEN 5 THEN 'very good' ELSE 'Not Specified' END, 
Longterm_Health_problem = Case  chhprob WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified' END, 'Ethiopia' as Country
FROM ethiopia_constructed$
WHERE round = 5
UNION
SELECT childid,  Cohort = CASE yc WHEN 0 THEN 'Older' WHEN 1 THEN 'Younger' ELSE 'Not Specified' END,
Serious_Illness = Case  chillness WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified'END,
Disability = Case  chdisability WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified'END,
Deadly_illness = Case  chmightdie WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified' END,
Childs_general_health = case chhealth WHEN 1 THEN 'very poor' WHEN 2 THEN 'poor' WHEN 3 THEN 'average' 
WHEN 4 THEN 'good' WHEN 5 THEN 'very good' ELSE 'Not Specified' END, 
Longterm_Health_problem = Case  chhprob WHEN 0 THEN 'NO' WHEN 1 THEN 'YES' ELSE 'Not Specified' END, 'Peru' as Country
FROM peru_constructed$
WHERE round = 5


/******Child Immunisation View ******/
CREATE VIEW Children_Immunisation AS
SELECT (childid), Tetanus_vaccination = case tetanus  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 
BCG_vaccination = case bcg  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 
Measles_vacinnation = case measles  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END,
Polio_vaccinations = case polio WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 'Ethiopia' as Country
FROM ethiopia_constructed$
WHERE ROUND =1 AND yc=1
UNION
SELECT (childid), Tetanus_vaccination = case tetanus  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 
BCG_vaccination = case bcg  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 
Measles_vacinnation = case measles  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END,
Polio_vaccinations = case polio WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 'Peru' as Country
FROM peru_constructed$
WHERE ROUND =1 AND yc=1
UNION
SELECT childid, Tetanus_vaccination = case tetanus  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 
BCG_vaccination = case bcg  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 
Measles_vacinnation = case measles  WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END,
Polio_vaccinations = case polio WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' END, 'Vietnam' as Country
FROM vietnam_constructed$
WHERE ROUND =1 AND yc=1


/******Anthropometric information View******/
CREATE VIEW Anthropometric_info
AS
SELECT childid, Cohort = CASE yc WHEN 0 THEN 'Older' WHEN 1 THEN 'Younger' ELSE 'Not Specified' END,
chweight AS Child_weight ,chheight,bmi, Low_weight_for_age = CASE underweight WHEN 0 THEN 'not underweight' 
WHEN 1 THEN 'moderately underweight'
WHEN 2 THEN 'severely underweight' ELSE 'Not specified' END, Short_height_for_age = CASE stunting WHEN 0 THEN 'not stunted' 
WHEN 1 THEN 'moderately stunted'
WHEN 2 THEN 'severely stunted' ELSE 'Not specified' END, Low_BMI_for_age = CASE thinness  WHEN 0 THEN 'not thin' 
WHEN 1 THEN 'moderately thin'
WHEN 2 THEN 'severely thin' ELSE 'Not specified' END, 'Peru' as Country
FROM peru_constructed$
WHERE round = 4 
UNION
SELECT childid, Cohort = CASE yc WHEN 0 THEN 'Older' WHEN 1 THEN 'Younger' ELSE 'Not Specified' END,
chweight AS Child_weight ,chheight,bmi, Low_weight_for_age = CASE underweight WHEN 0 THEN 'not underweight' 
WHEN 1 THEN 'moderately underweight'
WHEN 2 THEN 'severely underweight' ELSE 'Not specified' END, Short_height_for_age = CASE stunting WHEN 0 THEN 'not stunted' 
WHEN 1 THEN 'moderately stunted'
WHEN 2 THEN 'severely stunted' ELSE 'Not specified' END, Low_BMI_for_age = CASE thinness  WHEN 0 THEN 'not thin' 
WHEN 1 THEN 'moderately thin'
WHEN 2 THEN 'severely thin' ELSE 'Not specified' END, 'ethopia' as Country
FROM ethiopia_constructed$
WHERE round = 4 
UNION
SELECT childid, Cohort = CASE yc WHEN 0 THEN 'Older' WHEN 1 THEN 'Younger' ELSE 'Not Specified' END,
chweight AS Child_weight ,chheight,bmi, Low_weight_for_age = CASE underweight WHEN 0 THEN 'not underweight' 
WHEN 1 THEN 'moderately underweight'
WHEN 2 THEN 'severely underweight' ELSE 'Not specified' END, Short_height_for_age = CASE stunting WHEN 0 THEN 'not stunted' 
WHEN 1 THEN 'moderately stunted'
WHEN 2 THEN 'severely stunted' ELSE 'Not specified' END, Low_BMI_for_age = CASE thinness  WHEN 0 THEN 'not thin' 
WHEN 1 THEN 'moderately thin'
WHEN 2 THEN 'severely thin' ELSE 'Not specified' END, 'vietnam' as Country
FROM vietnam_constructed$
WHERE round = 4 


/*****Young Lives wealth index and sub-indices view******/
CREATE VIEW  Younglives_subindices AS
SELECT childid, Acess_to_electricity =  CASE elecq  WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END,
Access_to_sanitation =  CASE toiletq WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END, 
Access_to_safe_drinking_water =CASE drwaterq WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END, 'Peru' as Country
FROM peru_constructed$
WHERE round = 1
UNION
SELECT childid, Acess_to_electricity =  CASE elecq_new  WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END,
Access_to_sanitation = CASE toiletq_new WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END, 
Access_to_safe_drinking_water =CASE drwaterq_new WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END,'Vietnam' as Country
FROM vietnam_constructed$
WHERE round = 1
UNION
SELECT childid, Acess_to_electricity =  CASE elecq_new  WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END,
Access_to_sanitation =  CASE toiletq_new WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END, 
Access_to_safe_drinking_water =CASE drwaterq_new WHEN 1 THEN 'yes' WHEN 0 THEN 'no' END,'Ethiopia' as Country
FROM ethiopia_constructed$
WHERE round = 1


/******REPORT/CASE 1 *****/


/******Children with serious illness in Vietnam******/
WITH t1 AS (
SELECT COUNT(chillness) as Number_of_children, Serious_illness_Vietnam = Case  chillness
WHEN ' ' THEN 'Not Specified'
WHEN 0 THEN 'NO'
WHEN 1 THEN 'YES'
ELSE 'Not Specified'
END, 1 AS num
FROM vietnam_constructed$
WHERE ROUND = 5
GROUP BY chillness),
t2 AS (
SELECT CAST(Number_of_children AS decimal) AS Number_of_children , Serious_illness_Vietnam, SUM(Number_of_children) OVER (PARTITION BY num) AS Sum_Child
FROM t1)
SELECT Serious_illness_Vietnam, Number_of_children,  ROUND((Number_of_children/Sum_Child)*100, 1) AS [Percentage]
FROM t2
ORDER BY 2 DESC


/******REPORT/CASE 2 ****/


/******Children with serious illness in India******/
WITH t1 AS (
SELECT COUNT(chillness) as Number_of_children, Serious_Illness = Case  chillness
WHEN ' ' THEN 'Not Specified'
WHEN 0 THEN 'NO'
WHEN 1 THEN 'YES'
END, 1 AS num
FROM india_constructed$
WHERE ROUND = 5
GROUP BY chillness),
t2 AS (
SELECT CAST(Number_of_children AS decimal) AS Number_of_children , Serious_Illness, SUM(Number_of_children) OVER (PARTITION BY num) AS Sum_Child
FROM t1)
SELECT Serious_Illness,Number_of_children,  ROUND((Number_of_children/Sum_Child)*100, 1) AS [Percentage]
FROM t2
ORDER BY 2 DESC


/******REPORT/CASE 3 ****/


/****Comparing Child illness in india and vietnam****/
WITH t1 AS (
SELECT COUNT(childid) as children_from_india,Serious_Illness = Case  chillness
WHEN ' ' THEN 'Not Specified'
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END
FROM india_constructed$
WHERE ROUND = 5 
GROUP BY chillness),
t2 AS (
SELECT COUNT(childid) as children_from_vietnam,Serious_Illness = Case  chillness
WHEN ' ' THEN 'Not Specified'
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END
FROM vietnam_constructed$
WHERE ROUND = 5 
GROUP BY chillness)
SELECT t2.Serious_Illness, children_from_india, children_from_vietnam
FROM t1
JOIN t2
ON t1.Serious_Illness = t2.Serious_Illness
ORDER BY 2 DESC



/******REPORT/CASE 4 ****/


/******Children with at least 3 Vaccinations(Polio,Measles and Tetanu)******/
WITH
t1 AS (
SELECT Polio_vaccinations, Measles_vacinnation,Tetanus_vaccination ,COUNT(*) as Number_of_children,Country
FROM Children_Immunisation
WHERE Polio_vaccinations = 'yes' and Measles_vacinnation = 'yes' and Tetanus_vaccination = 'yes'
GROUP BY Polio_vaccinations,Measles_vacinnation, Country, Tetanus_vaccination),
t2 AS (
SELECT COUNT(*) total , Country
FROM Children_Immunisation
GROUP BY Country)
select t1.Polio_vaccinations, t1.Measles_vacinnation,t1.Tetanus_vaccination ,t1.Number_of_children,t2.total, t1.Country
from t1 join t2
on t1.Country =t2.Country



/******REPORT/CASE 5 ****/


/******Underage Marriages******/
select count(*) Teenage_marriages, Married = case marrcohab WHEN 0 THEN 'Not Married' WHEN 1 THEN 'Married' END, 'Peru' as Country
from peru_constructed$
where marrcohab = 1 and (marrcohab_age between 0 and 18)
group by marrcohab 
union
select count(*) Teenage_marriages, Married = case marrcohab WHEN 0 THEN 'Not Married' WHEN 1 THEN 'Married' END, 'Vietnam' as Country
from vietnam_constructed$
where marrcohab = 1 and (marrcohab_age between 0 and 18)
group by marrcohab
union
select count(*) Teenage_marriages, Married = case marrcohab WHEN 0 THEN 'Not Married' WHEN 1 THEN 'Married' END, 'Ethopia' as Country
from ethiopia_constructed$
where marrcohab = 1 and (marrcohab_age between 0 and 18)
group by marrcohab



 
/******REPORT/CASE 6 ****/


/***Children with very Low BMI***/
SELECT  Low_BMI_for_age, Country,COUNT(*) as Number_of_children
FROM Anthropometric_info
WHERE Low_BMI_for_age = 'moderately thin' or Low_BMI_for_age = 'severely thin'
GROUP BY Low_BMI_for_age,Country
ORDER BY 2

/******REPORT/CASE 7 ****/


 /***Average BMI across younglife Coutries***/
SELECT AVG(bmi) BMI, Country, cohort
FROM Anthropometric_info
GROUP BY Country, cohort
ORDER BY 2



/******REPORT/CASE 8 ****/


/***Number of literate children in india (children who can read and write without difficulty)***/
SELECT COUNT(childid) as 'Number of illiterate children', Cohort = 
	  CASE yc
	     WHEN 0 THEN 'Older'  
         WHEN 1 THEN 'Younger'
		 ELSE 'Not Specified'
	  END,'Ethiopia' AS Country
FROM ethiopia_constructed$
WHERE ROUND = 2 AND literate = 1 and yc =0
GROUP BY yc
ORDER BY 2


/******REPORT/CASE 9 ****/


/***Number of literate children in vietnam***/
SELECT COUNT(childid) as 'Number of illiterate children',Cohort = 
	  CASE yc
	     WHEN 0 THEN 'Older'  
         WHEN 1 THEN 'Younger'
		 ELSE 'Not Specified'
	  END,'Vietnam' AS Country
FROM vietnam_constructed$
WHERE ROUND = 2 AND literate = 1 and (yc =0 or yc =1)
GROUP BY yc
ORDER BY 2


/******REPORT/CASE 10 ****/


/***Number of literate children in India***/
SELECT COUNT(childid) as 'Number of illiterate children',Cohort = 
	  CASE yc
	     WHEN 0 THEN 'Older'  
         WHEN 1 THEN 'Younger'
		 ELSE 'Not Specified'
	  END, 'India' AS Country
FROM india_constructed$
WHERE ROUND = 2 AND literate = 1 and yc =0
GROUP BY yc
ORDER BY 2


/******REPORT/CASE 11 ****/


/***Comparing  literacy in india and vietnam***/
WITH t1 AS (
SELECT COUNT(childid) as children_from_india, literacy = Case  literate
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END
FROM india_constructed$
WHERE ROUND = 2 and yc = 0 and literate =1
GROUP BY literate),
t2 AS (
SELECT COUNT(childid) as children_from_vietnam,literacy = Case  literate
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END
FROM vietnam_constructed$
WHERE ROUND = 2 and yc = 0 and literate =1
GROUP BY literate)
SELECT t2.literacy, children_from_india, children_from_vietnam
FROM t1
JOIN t2
ON t1.literacy = t2.literacy
ORDER BY 2 DESC


/******REPORT/CASE 12 ****/


/***Number of children enrolled in school in india***/
WITH t1 AS (
SELECT COUNT(enrol) as Number_of_children, Enrolled_in_school = Case  enrol
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END, 1 AS num
FROM india_constructed$
WHERE ROUND = 5
GROUP BY enrol),
t2 AS (
SELECT CAST(Number_of_children AS decimal) AS Number_of_children , Enrolled_in_school, SUM(Number_of_children) OVER (PARTITION BY num) AS Sum_Child
FROM t1)
SELECT Enrolled_in_school,Number_of_children, ROUND((Number_of_children/Sum_Child)*100, 1) AS Child_percent, 'India' as Country
FROM t2
ORDER BY 2 DESC



/******REPORT/CASE 13 ****/


/***Number of children enrolled in school in vietnam***/
WITH t1 AS (
SELECT COUNT(enrol) as Number_of_children, Enrolled_in_school = Case  enrol
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END, 1 AS num
FROM vietnam_constructed$
WHERE ROUND = 5
GROUP BY enrol),
t2 AS (
SELECT CAST(Number_of_children AS decimal) AS Number_of_children , Enrolled_in_school, SUM(Number_of_children) OVER (PARTITION BY num) AS Sum_Child
FROM t1)
SELECT Enrolled_in_school, Number_of_children, ROUND((Number_of_children/Sum_Child)*100, 1) AS Child_percent, 'Vietnam' as Country
FROM t2
ORDER BY 2 DESC


/******REPORT/CASE 14 ****/


/***Comparing children enrolled in school in india and vietnam***/
WITH t1 AS (
SELECT COUNT(childid) as children_from_india,Enrolled_in_school = Case  enrol
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END
FROM india_constructed$
WHERE ROUND = 5 
GROUP BY enrol),
t2 AS (
SELECT COUNT(childid) as children_from_vietnam,Enrolled_in_school = Case  enrol
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes'
ELSE 'Not Specified'
END
FROM vietnam_constructed$
WHERE ROUND = 5 
GROUP BY enrol)
SELECT t2.Enrolled_in_school, children_from_india, children_from_vietnam
FROM t1
JOIN t2
ON t1.Enrolled_in_school = t2.Enrolled_in_school
ORDER BY 2 DESC



/******REPORT/CASE 15 ****/


/***Access to Drinking water***/
with t1 AS (
select Access_to_safe_drinking_water, count(*) Number_of_children,  Country
from Younglives_subindices
where Access_to_safe_drinking_water = 'yes'
group by Access_to_safe_drinking_water, Country),
t2 AS (
select count(*) AS total, Country
from Younglives_subindices
group by Country)
select  t1.Access_to_safe_drinking_water,t1.Number_of_children,t2.total, t1.Country
from t1 join t2
on t1.Country =t2.Country




/******REPORT/CASE 16 ****/


/***Access to Sanitation***/
with t1 AS (
select Access_to_sanitation,count(*) Number_of_children, Country
from Younglives_subindices
where Access_to_sanitation = 'yes'
group by Access_to_sanitation, Country),
t2 AS (
select count(*) AS total, Country
from Younglives_subindices
group by Country)
select  t1.Access_to_sanitation,t1.Number_of_children,t2.total, t1.Country
from t1 join t2
on t1.Country =t2.Country



--STORED PROCEDURE
CREATE PROCEDURE [dbo].[Health_records_page] 
	@country nvarchar(25), 
	@startpage int,
	@endpage int
AS
BEGIN
	SET NOCOUNT ON;

SELECT *
FROM Child_Health_Condtion
WHERE Country = @country
ORDER BY childid
OFFSET @startpage ROWS FETCH NEXT @endpage ROWS ONLY
END
---TEST
EXECUTE [Health_records_page] N'vietnam', N'20', N'30'


--TRIGGERS
CREATE TRIGGER error101 
ON ethiopia_constructed$
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 
CREATE TRIGGER error102 
ON peru_constructed$
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 
CREATE TRIGGER error103 
ON vietnam_constructed$
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 
CREATE TRIGGER error104 
ON india_constructed$
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 




/*****SCRIPTS FOR TASK 2*****/

--Transaction Isolation Level
USE [ADB Task2];  
GO  
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
---Academic Support View
CREATE VIEW Academic_support
AS
SELECT UNIQUEID, SCHOOLID, PROVINCE = CASE PROVINCE WHEN 1 THEN 'Ben Tre'
WHEN 2 THEN 'Da Nang'
WHEN 3 THEN 'Hung Yen'
WHEN 4 THEN 'Lao Cai'
WHEN 5 THEN 'Phu Yen' END,
'DISTRICT' = CASE  DISTRICTCODE
WHEN 1 THEN 'PY1'
WHEN 2 THEN 'PY2'
WHEN 3 THEN 'PY3'
WHEN 4 THEN 'PY4'
WHEN 5 THEN 'BT1'
WHEN 6 THEN 'BT2'
WHEN 7 THEN 'LC1'
WHEN 8 THEN 'LC2'
WHEN 9 THEN 'LC3'
WHEN 10 THEN 'HY1'
WHEN 11 THEN 'HY2'
WHEN 12 THEN 'DN1'
WHEN 13 THEN 'DN2' END,
'SUPPORT WITH SCHOOLWORK' = CASE STPLHLRD
WHEN 0 THEN 'Never'
WHEN 1 THEN 'Sometimes'
WHEN 2 THEN 'Always'
ELSE 'Not Specified' END,
'DISCUSSION ABOUT SCHOOL PERFORMANCE' = CASE STPLHL01 
WHEN 1 THEN 'Never or almost never'
WHEN 2 THEN 'Once or twice a month'
WHEN 3 THEN 'Once or twice a week'
WHEN 4 THEN 'Every day or almost every day'
ELSE 'Not Specified' END,
'SUPPORT WITH MATHS HOMEWORK' = CASE STPLHL03
WHEN 1 THEN 'Never or almost never'
WHEN 2 THEN 'Once or twice a month'
WHEN 3 THEN 'Once or twice a week'
WHEN 4 THEN 'Every day or almost every day'
ELSE 'Not Specified' END,
'SUPPORT WITH ENGLISH HOMEWORK' = CASE STPLHL06
WHEN 1 THEN 'Never or almost never'
WHEN 2 THEN 'Once or twice a month'
WHEN 3 THEN 'Once or twice a week'
WHEN 4 THEN 'Every day or almost every day'
ELSE 'Not Specified' END
FROM vietnam_wave_1$


--- HEAD TEACHER VIEW
CREATE VIEW Head_Teacher
AS
SELECT DISTINCT(SCHOOLID),PROVINCE = CASE PROVINCE WHEN 1 THEN 'Ben Tre'
WHEN 2 THEN 'Da Nang'
WHEN 3 THEN 'Hung Yen'
WHEN 4 THEN 'Lao Cai'
WHEN 5 THEN 'Phu Yen' END,HTAGE as 'AGE','GENDER' = CASE  HTSEX WHEN 1 THEN 'Male'
WHEN 2 THEN 'Female 'END, HTYRSHT AS 'YEARS IN ROLE', 'EDUCATION LEVEL' = CASE HTLVLEDC
WHEN 3.0 THEN 'College education'
WHEN 1.0 THEN 'Upper secondary or equivalent'
WHEN 2.0 THEN 'Vocational training school'
WHEN 99.0 THEN 'Missing'
WHEN 4.0 THEN 'University education (undergraduate)'
WHEN 5.0 THEN 'University education (postgraduate)'
END, 'TRAINING' = CASE HTLVLTCH 
WHEN 0.0 THEN 'I am not trained'
WHEN 1.0 THEN 'Short course or crash course in teaching profession'
WHEN 2.0 THEN 'Teacher training level (2 years after upper secondary education)'
WHEN 3.0 THEN 'Teacher training college level (3 years after upper secondary education)'
WHEN 4.0 THEN 'Teacher training university level (4 years after upper secondary education) or higher'
WHEN 99.0 THEN 'Missing'
WHEN 88.0 THEN 'NA' END,
'Excellent teacher award' = CASE HTEXCTCH 
WHEN 0.0 THEN 'been an excellent teacher'
WHEN 1.0 THEN 'Yes, school level'
WHEN 2.0 THEN 'Yes, district level'
WHEN 3.0 THEN 'Yes, province level or higher'
WHEN 99.0 THEN 'Missing' END
FROM vietnam_wave_1$


--SCHOOL VIEW
CREATE VIEW School
AS
SELECT DISTINCT(SCHOOLID), PROVINCE = CASE PROVINCE
WHEN 1 THEN 'Ben Tre'
WHEN 2 THEN 'Da Nang'
WHEN 3 THEN 'Hung Yen'
WHEN 4 THEN 'Lao Cai'
WHEN 5 THEN 'Phu Yen' END ,'Type of School' = CASE HTTYPSCH
WHEN 1 THEN 'Government'
WHEN 2 THEN 'Private'
WHEN 3 THEN  'Other' END,
'Extra-curricular activies' = CASE HTEXTCUR
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END,
HTYREST as 'Year school was established', HTCENMST AS 'Number of Teachers (Grades 10 -12)',
HTNMSTEN AS 'Students Enrolled'
FROM vietnam_wave_1$


--Household Economic adavantage View
CREATE VIEW Household_economic_advantage
AS
SELECT UNIQUEID, PROVINCE = CASE PROVINCE
WHEN 1 THEN 'Ben Tre'
WHEN 2 THEN 'Da Nang'
WHEN 3 THEN 'Hung Yen'
WHEN 4 THEN 'Lao Cai'
WHEN 5 THEN 'Phu Yen' END,
STUDYPLACE = CASE STPLSTDY 
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END,
DESK = CASE STHVDESK 
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END, 
CHAIR = CASE STHVCHR 
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END, LAMP = CASE STHVLAMP
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END, SCHOOLBAG = CASE STITMOW5 
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END, POCKET_CALCULATOR = CASE STITMOW8
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END, RULER = CASE STITMOW6
WHEN 0 THEN 'No'
WHEN 1 THEN 'Yes' END
FROM vietnam_wave_1$


--TEST SCORES VIEW
CREATE VIEW Maths_English_scores
AS
SELECT UNIQUEID, PROVINCE = CASE PROVINCE WHEN 1 THEN 'Ben Tre'
WHEN 2 THEN 'Da Nang'
WHEN 3 THEN 'Hung Yen'
WHEN 4 THEN 'Lao Cai'
WHEN 5 THEN 'Phu Yen' END,
'DISTRICT' = CASE  DISTRICTCODE
WHEN 1 THEN 'PY1'
WHEN 2 THEN 'PY2'
WHEN 3 THEN 'PY3'
WHEN 4 THEN 'PY4'
WHEN 5 THEN 'BT1'
WHEN 6 THEN 'BT2'
WHEN 7 THEN 'LC1'
WHEN 8 THEN 'LC2'
WHEN 9 THEN 'LC3'
WHEN 10 THEN 'HY1'
WHEN 11 THEN 'HY2'
WHEN 12 THEN 'DN1'
WHEN 13 THEN 'DN2' END,MATH_RAWSCORE, ENG_RAWSCORE
FROM vietnam_wave_1$


--Students with no schoolwork support by district
SELECT PROVINCE, COUNT([SUPPORT WITH SCHOOLWORK]) as 'Students without schoolwork support'
FROM Academic_support
WHERE [SUPPORT WITH SCHOOLWORK] LIKE '%Never%' AND DISTRICT is not null
GROUP BY PROVINCE
ORDER BY 2 DESC


-- School types across provinces
SELECT DISTINCT(PROVINCE), [Type of School], COUNT(*) as [Number of Schools]
FROM School
GROUP BY PROVINCE,[Type of School]
ORDER BY 3 DESC

-- Teachers across provinces
SELECT DISTINCT(PROVINCE), SUM([Number of Teachers (Grades 10 -12)])
FROM School
GROUP BY PROVINCE
ORDER BY 2 DESC


--Children with the most Household advantage
SELECT PROVINCE, COUNT(*) as [Number of children]
FROM Household_economic_advantage
WHERE STUDYPLACE = 'yes' AND DESK = 'yes' AND CHAIR ='yes' AND SCHOOLBAG ='yes' AND RULER ='yes'
GROUP BY PROVINCE
ORDER BY 2 DESC


---Average Math Test Scores by Province
SELECT PROVINCE, ROUND(AVG(MATH_RAWSCORE),1) AS [Average Math scores]
FROM Maths_English_scores
GROUP BY PROVINCE
ORDER BY 2 DESC


------Average English Test Scores by Province
SELECT PROVINCE, ROUND(AVG(ENG_RAWSCORE),1) AS [Average English scores]
FROM Maths_English_scores
GROUP BY PROVINCE
ORDER BY 2 DESC

------Average Math and English Test Scores by Province
SELECT PROVINCE, ROUND(AVG(MATH_RAWSCORE),1) AS [Average Math scores], ROUND(AVG(ENG_RAWSCORE),1) AS [Average English scores]
FROM Maths_English_scores
GROUP BY PROVINCE
ORDER BY 2 DESC


--Teacher Qualification
SELECT   Province = CASE PROVINCE WHEN 1 THEN 'Ben Tre'
WHEN 2 THEN 'Da Nang'
WHEN 3 THEN 'Hung Yen'
WHEN 4 THEN 'Lao Cai'
WHEN 5 THEN 'Phu Yen' END, COUNT(HTLVLEDC) Teacher_is_a_graduate_or_higher
FROM vietnam_wave_1$
WHERE HTLVLEDC IN (4,5)
GROUP BY PROVINCE
ORDER BY 2 DESC


---Stored Procedure
CREATE PROCEDURE [Test Score Finder] @uniqueid nvarchar(30)
AS
SELECT MATH_RAWSCORE as [Math Score], ENG_RAWSCORE as [English Score]
FROM Maths_English_scores
WHERE UNIQUEID = @uniqueid
GO

EXEC [Test Score Finder] @uniqueid	= 'VN1203102'

--Triggers
CREATE TRIGGER error101 
ON vietnam_wave_1$
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 






/*****SCRIPTS FOR TASK 3*****/


--Transaction Isolation Level
USE [ADB Task 3];  
GO  
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

--- Greater manchester crime tables
SELECT *
 FROM [ADB Task 3].[dbo].[Full greater manchester street]

--Population table
 SELECT *
 FROM [Mid-2020 Persons]

 ---Media age table
  SELECT *
 FROM [Median Age]


 --Script for adding new column 'Geolocation' with Geography data type
 ALTER TABLE [Full greater manchester street]
 ADD [Geolocation] GEOGRAPHY


 --- Creating an instance of Geography point on the Geolocation point for Spatial analysis
 UPDATE [Full greater manchester street]
SET [Geolocation] = geography::Point(Latitude, Longitude, 4326)
WHERE [Longitude] IS NOT NULL
AND [Latitude] IS NOT NULL
AND CAST(Latitude AS decimal(10, 6)) BETWEEN -90 AND 90
AND CAST(Longitude AS decimal(10, 6)) BETWEEN -90 AND 90


---Adding Primary key constraint to table for geospatial analysis
ALTER TABLE [Full greater manchester street]
ADD ID INT IDENTITY;
ALTER TABLE [Full greater manchester street]
ADD CONSTRAINT PK_Id PRIMARY KEY NONCLUSTERED (ID);
GO

--All Views

---Vehcile crime View
CREATE View Vechicle_crime
AS
SELECT c.ID, [Crime type], p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Longitude,c.Latitude,c.Month, c.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Vehicle crime'


--Anti social behaviour crime in Salford
CREATE View [Anti-social behaviour salford]
AS
SELECT c.ID,[Crime type], p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Month, C.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Anti-social behaviour' AND p.[LSOA name] LIKE'%salford%'


---Shoplifting View for Greater Manchester
CREATE View Shoplifting
AS
SELECT [Crime type], p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Longitude,c.Latitude,c.Month,c.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Shoplifting'

---Burglary View for Greater Manchester
CREATE View [Burglary crime]
AS
SELECT [Crime type] as Burglary, p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Longitude,c.Latitude,c.Month,c.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Burglary'


---TOP 10 CRIMES IN GM
SELECT TOP (10) c.[Crime type], COUNT([Crime type]) AS [Crime count]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
GROUP BY c.[Crime type]
ORDER BY 2 DESC


---TOP 10 CRIME PRONE AREAS IN GM
SELECT TOP (10) p.[LA name (2021 boundaries)], COUNT([Crime type]) AS [Crime count]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 2 DESC



---Shoplifting in Greater Manchester
SELECT COUNT([Crime type]) AS [Shoplifting],p.[LA name (2021 boundaries)]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Shoplifting'
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 1 DESC

--Median age of shoplifters
SELECT TOP (10) COUNT([Crime type]) AS [Shoplifting], a.[median age]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Shoplifting'
GROUP BY a.[median age]
ORDER BY 1 DESC 


---Vehicle crime in Greater Manchester
SELECT COUNT([Crime type]) AS [Vehicle crime],p.[LA name (2021 boundaries)]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
WHERE [Crime type] = 'Vehicle crime'
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 1 DESC

--Anti social behaviour in Greater manchester
SELECT COUNT([Crime type]) AS [Anti-social behaviour],p.[LA name (2021 boundaries)]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
WHERE [Crime type] = 'Anti-social behaviour' 
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 1 DESC


---Stored Procedure 

CREATE PROCEDURE [Top 10 Crimes by City] @City nvarchar(30)
AS
SELECT TOP (10) c.[Crime type], COUNT([Crime type]) AS [Crime count]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
WHERE C.[LSOA name] LIKE '%' + @City + '%'
GROUP BY c.[Crime type]
ORDER BY 2 DESC
GO

EXEC [Top 10 Crimes by City] @city	= 'salford'


--Triggers

CREATE TRIGGER error101 
ON [Full greater manchester street]
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 
CREATE TRIGGER error102 
ON [Mid-2020 Persons]
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 